# File-structures-secondary-indexing
File structures mini project using secondary indexing method

<img src ='/img/home.png'/>
The Home Page of the Movie Library where we can login as a User or Admin.

<img src ='/img/adminlogin.png'/>
Admin Login

<img src ='/img/adminhome.png'/>
Admin Home Page
 

<img src ='/img/usersignup.png'/> 
User Sign Up/Add User


<img src ='/img/adminmod.png'/>
The Modify User page where the admin has to check if the user exists and then click on modify user to modify his details.


<img src ='/img/adminmod1.png'/>
The Modify User page where the admin can modify the user details.
 

<img src ='/img/adminuserdel.png'/>
Delete User page where the admin can delete the user.

 
<img src ='/img/addmovie.png'/>
Add Movie page where the admin can insert a movie to the Movie Library.
 

<img src ='/img/modmovie.png'/>
Modify Movie page where the admin has to check if the movie exists and then click on modify movie button to modify his details.

 
<img src ='/img/modmovie2.png'/>
Modify Movie page where the admin can modify the movie details.


<img src ='/img/delmovie.png'/>
Delete Movie page where the admin can delete the movie.

 
<img src ='/imguserlogin.png'/>
User Login Page

 
<img src ='/img/library.png'/>
User home page displaying the Top Movies recommended by the Top Recommendation System.

 
<img src ='/img/allmovie.png'/>
User home page, displaying all the movies.

 
<img src ='/img/moviedisp.png'/>
Movie details, ratings and reviews.

 
<img src ='/img/movierating.png'/>
The Movie details, ratings and reviews. The user will be able to enter the ratings and reviews to the movie if not given before, else will show add rating option. It also displays recommendation based on the movie selected.
